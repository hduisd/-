package com.viktor.worldgen;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.Climate;
import terrablender.api.Region;
import terrablender.api.RegionType;

import java.util.function.Consumer;

/** Регіон TerraBlender: у частині світу рівнини, ліси й савани замінюються на «Байківецьку землю». */
public class BaykivetskaRegion extends Region {
    public BaykivetskaRegion(ResourceLocation name, int weight) {
        super(name, RegionType.OVERWORLD, weight);
    }

    @Override
    public void addBiomes(Registry<Biome> registry, Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> mapper) {
        this.addModifiedVanillaOverworldBiomes(mapper, builder -> {
            builder.replaceBiome(Biomes.PLAINS, ModBiomes.BAYKIVETSKA_LAND);
            builder.replaceBiome(Biomes.FOREST, ModBiomes.BAYKIVETSKA_LAND);
            builder.replaceBiome(Biomes.SAVANNA, ModBiomes.BAYKIVETSKA_LAND);
        });
    }
}
